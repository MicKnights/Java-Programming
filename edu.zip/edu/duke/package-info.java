/**
 * Resource classes for Duke/Coursera course.
 */
package edu.duke;
